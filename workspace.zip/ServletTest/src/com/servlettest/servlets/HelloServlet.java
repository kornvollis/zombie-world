package com.servlettest.servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	final static Charset ENCODING = StandardCharsets.UTF_8;
	private File file = new File("C:\\Users\\Viktor_Potharn@epam.com\\workspace\\ServletTest\\src\\data_file");
	private Properties prop;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String url_key   = request.getParameter("key");
		String url_value = request.getParameter("value");
		
		PrintWriter out = response.getWriter();
         out.println("<html><head>"+
         "</head><body>"+
         "<form name='myform' action='http://localhost:8080/ServletTest/HelloServlet' method='GET'>"+
         	"KEY:   <input id='key' name='key'></input>"+
         	"VALUE: <input id='value' name='value'></input>" +
         	"<input type='submit' value='Submit!'>");
        
         
         
         //load a properties file
 		 prop.load(new FileInputStream(file));
         
 		 if(url_key != null && url_key !="" && url_value != null && url_value!="")
 		 {
 			 prop.setProperty(url_key, url_value);
 		 }
         
         //prop.put("2030", "alma");
        
         FileOutputStream outputStream = new FileOutputStream(file);  
         
         prop.store(outputStream, "my comment");
         
         out.println("<br>");
         
         Enumeration<?> e = prop.propertyNames();
         while (e.hasMoreElements()) {
           String key = (String) e.nextElement();
           out.println("<div>" + key + " : " + prop.getProperty(key) + "</div>");
         }
         
         out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
