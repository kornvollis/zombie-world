
public class MySet 
{
	private int[] elements = new int[100];
	
	int numOfElements = 0;
	
	public int remove(int value)
	{
		boolean hasValue = false;
		int position = -1;
		for (int i = 0; i < numOfElements; i++) {
			if(value == elements[i]) {
				hasValue = true;
				position = i;
				break;
			}
		}
		
		if(hasValue) {
			for (int i = position; i < numOfElements; i++) {
				elements[position] = elements[position+1];
			}
			numOfElements--;
			return 1;
		}
		
		return -1;
	}
	
	public int push(int value)
	{
		for (int i = 0; i < elements.length; i++) {
			if(elements[i] == value) return -1;
		}
		
		if(numOfElements < elements.length)
		{
			elements[numOfElements] = value;
			
			numOfElements++;
			
			return 1;
		}
		
		
		return -1;
	}
	
	@Override public String toString() 
	{
		String actualElements = "Elements: ";
		
		for (int i = 0; i < numOfElements; i++) {
			actualElements+= elements[i] + ", ";
		}
		
		actualElements = actualElements.substring(0, actualElements.length()-2);
		
		return actualElements;
	}
}
