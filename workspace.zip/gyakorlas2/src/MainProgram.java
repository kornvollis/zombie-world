
class MainProgram {

	public static void main(String [] args)
	{
		MySet kishalmazka = new MySet();
		
		kishalmazka.push(54);
		//kishalmazka.push(74);
		//kishalmazka.push(174);
		//kishalmazka.push(274);
		//kishalmazka.push(374);
		
		kishalmazka.remove(54);
		kishalmazka.remove(54);
		
		kiir(kishalmazka.toString());
		
		char chr = 64;
		
		System.out.println(chr);
		
	}
	
	
	public static void kiir(String str)
	{
		System.out.println(str);
	}
}
