package quiz;

import java.util.Random;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.sun.xml.internal.ws.api.pipe.ClientTubeAssemblerContext;

@ManagedBean(name="game")
@SessionScoped
public class GameBean {

	private Integer guessingNumber = -1;
	
	private Integer clientGuess = 0;
	
	public Integer getClientGuess() {
		return clientGuess;
	}

	public void setClientGuess(Integer clientGuess) {
		this.clientGuess = clientGuess;
	}

	public GameBean() {
		 Random randomGenerator = new Random();
		 guessingNumber = randomGenerator.nextInt(100);
	}
	
	public Integer getGuessingNumber() {
		return guessingNumber;
	}

	public void setGuessingNumber(Integer guessingNumber) {
		this.guessingNumber = guessingNumber;
	}
	
	public String myActionControllerMethod() {
	    return("game_result");  // Means to go to page-a.xhtml (since condition is not mapped in faces-config.xml)
	  }

	public void generateNewNum() {
		Random randomGenerator = new Random();
		guessingNumber = randomGenerator.nextInt(100);
	}
	
	public String getProcessGuess() {
		if(this.clientGuess < this.guessingNumber) {
			return "Your guess is smaller";
		}else if(this.clientGuess > this.guessingNumber) {
			return "Your guess is bigger";
		} 
		
		return "Your have found the correct number!";
	}
	
}
