package somePackage;

import javax.faces.bean.*;

@ManagedBean
public class MyBean {
    private String name = "";
    
    
    
	public String getBark() {
		if(name.length() == 0) return "";
		return name;
	}

	
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
}
