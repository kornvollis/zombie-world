
public class MyBean {

}
