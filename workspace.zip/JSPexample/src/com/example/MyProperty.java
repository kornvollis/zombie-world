package com.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

public class MyProperty {
	private Properties prop = new Properties();
	private File file = new File("C:\\Users\\Viktor_Potharn@epam.com\\workspace\\JSPexample\\data");
	
	private ArrayList<MyDate> list;
	private String avg = "";
	
	public MyProperty() {
		try {
			prop.load(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getElements();
	}
	
	public List<MyDate> getElements() {
		list = new ArrayList<MyDate>();
		
		Enumeration<?> e = prop.propertyNames();

	    while (e.hasMoreElements()) {
	      String key = (String) e.nextElement();

	      String[] values = prop.getProperty(key).split("\\|");
	      
    	  MyDate myDate = new MyDate();	      
	      Integer length = values.length;
	      if(length == 2)
	      {
	    	  int checkinHour = Integer.parseInt(values[0].split("\\:")[0]);
	    	  int checkinMin = Integer.parseInt(values[0].split("\\:")[1]);
	    	  
	    	  int checkoutHour = Integer.parseInt(values[1].split("\\:")[0]);
	    	  int checkoutMin = Integer.parseInt(values[1].split("\\:")[1]);
	    	  
	    	  myDate.setCheckDate(key);
	    	  
		      myDate.setCheckInHour(checkinHour);
		      myDate.setCheckInMin(checkinMin);
		      
		      myDate.setCheckOutHour(checkoutHour);
		      myDate.setCheckOutMin(checkoutMin);
		      
		      list.add(myDate);
	       } 
	    }
		
		return list;
	}

	public String getAvg() {
		Integer durationMin = 0;
		int numOfDays = list.size();
		
		if(numOfDays == 0) {
			return "0";
		}
		
		for (int i = 0; i < list.size() ; i++) {
			MyDate date = list.get(i);
			durationMin += date.durationMin();
		}

		durationMin = durationMin/numOfDays;
		
		Integer minReminder = durationMin%60;
		
		String zero = "";
		if(minReminder < 10) zero = "0";
		
		return ""+ (durationMin/60) + ":" + zero + minReminder;
		//return ("kaka");
	}

	public void setAvg(String avg) {
		this.avg = avg;
	}
}
