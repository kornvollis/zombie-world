package com.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FormHandler
 */
public class FormHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private File file = new File("C:\\Users\\Viktor_Potharn@epam.com\\workspace\\JSPexample\\data");
	private Properties prop = null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormHandler() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String date = request.getParameter("date");
		String checkIn = request.getParameter("check_in");
		String checkOut = request.getParameter("check_out");
		
		
		//VALIDATIONS
		if(request.getParameter("delete") == null) {
			if(!date.matches("[1-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]")) {
				response.sendRedirect("http://localhost:8080/JSPexample?error=Please use this date format YYYY-MM-DD");
				return;
			}
			if(!checkIn.matches("[0-9][0-9]:[0-9][0-9]")) {
				response.sendRedirect("http://localhost:8080/JSPexample?error=Please use this format for check in HH:MM");
				return;
			}
			if(!checkOut.matches("[0-9][0-9]:[0-9][0-9]")) {
				response.sendRedirect("http://localhost:8080/JSPexample?error=Please use this format for check out HH:MM");
				return;
			}
		}
		
		// TODO Auto-generated method stub
		prop = new Properties();
		
		 try {
			prop.load(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 

		//DELETE
		if(request.getParameter("delete") != null)
		{
			prop.remove(request.getParameter("delete"));
		}
		 
		
		if(checkIn != null && checkIn != "" && checkOut != null && checkOut != "") 
		{
			if(prop != null) {
				if(date != null && date == "")
				{
					Date currentDate = new Date();
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");	
					
					date = dateFormat.format(currentDate);
				}
				
				prop.setProperty(date+"", checkIn+"|"+checkOut);
			}
		}
				
		FileOutputStream outputStream = new FileOutputStream(file);  
        prop.store(outputStream, "my comment");
        response.sendRedirect("http://localhost:8080/JSPexample/");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	public void setProp(Properties p) {
		this.prop = p;
	}
}
