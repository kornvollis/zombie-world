package com.example;

public class MyDate {
	
	private int checkInHour=0;
	private int checkOutHour=0;
	private int checkInMin=0;
	private int checkOutMin=0;
	private String checkDate="";
	
	public MyDate() {
		
	}

	public Integer durationMin() {
		
		Integer duration = (checkOutMin + checkOutHour*60) - (checkInMin + checkInHour*60);
		return duration;
	}
	
	public String getCheckIn() {
		String zero = "";
		if(checkInMin < 10) zero = "0";
		return ""+checkInHour+":"+zero+checkInMin;
	}

	public String getCheckOut() {
		String zero = "";
		if(checkOutMin < 10) zero = "0";
		return ""+checkOutHour+":"+zero+checkOutMin;
	}
	
	public String getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}



	public int getCheckInHour() {
		return checkInHour;
	}



	public void setCheckInHour(int checkInHour) {
		this.checkInHour = checkInHour;
	}



	public int getCheckOutHour() {
		return checkOutHour;
	}



	public void setCheckOutHour(int checkOutHour) {
		this.checkOutHour = checkOutHour;
	}



	public int getCheckInMin() {
		return checkInMin;
	}



	public void setCheckInMin(int checkInMin) {
		this.checkInMin = checkInMin;
	}



	public int getCheckOutMin() {
		return checkOutMin;
	}



	public void setCheckOutMin(int checkOutMin) {
		this.checkOutMin = checkOutMin;
	}
}
