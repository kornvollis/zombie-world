import java.awt.Point;
import java.util.Random;


public class Apple 
{
	private Point positon;	
	
	public Apple(Point pos)
	{
		positon = pos;
	}

	
	public Point getPosition() {return positon;}


	public void respawn() 
	{
		Random random = new Random();
		
		int x = (int) (Math.random()*15);
		int y = (int) (Math.random()*15);
		
		System.out.println(x + "  " + y);
		
		positon.x = x;
		positon.y = y;
	}
}
