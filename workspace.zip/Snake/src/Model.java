import java.awt.Point;


public class Model 
{
	public static final int GRID_SIZE  = 20;
	public static final int MAP_WIDTH  = 20;
	public static final int MAP_HEIGHT = 15;
	
	
	public static Boolean pause = false;
	
	public Snake snakey = new Snake();
	
	public Apple apple = new Apple(new Point(10,7));
	
	
	
	
	public void update()
	{
		if(!pause)
		{
			snakey.update();
			
			if(apple.getPosition().x == snakey.pieces[0].x && 
			   apple.getPosition().y == snakey.pieces[0].y)
			{
				snakey.grow();
				apple.respawn();
				System.out.println("GROW");
			}
			
			
			if(snakey.isCollide()) {
				pause = true;
			}
		}		
	}
	
}
