import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Controller implements KeyListener {
	
	private Model model;
	private View view;
	
	public Controller(Model model, View view)
	{
		this.model = model;
		this.view  = view;
		
		//view.panel.addKeyListener(this);
		view.mainFrame.addKeyListener(this);
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		int code = arg0.getKeyCode();
		
		if(code == 38)
		{
			if(model.snakey.status != Snake.TOP_MOVE && 
			   model.snakey.status != Snake.DOWN_MOVE)
			{
				model.snakey.status = Snake.TOP_MOVE;
			}
		} else if(code == 40)
		{
			if(model.snakey.status != Snake.TOP_MOVE && 
			   model.snakey.status != Snake.DOWN_MOVE)
			{
				model.snakey.status = Snake.DOWN_MOVE;
			}
		} else if(code == 37)
		{
			if(model.snakey.status != Snake.LEFT_MOVE&& 
			   model.snakey.status != Snake.RIGHT_MOVE)
			{
				model.snakey.status = Snake.LEFT_MOVE;
			}
		} else if(code == 39)
		{
			if(model.snakey.status != Snake.LEFT_MOVE&& 
			   model.snakey.status != Snake.RIGHT_MOVE)
			{
				model.snakey.status = Snake.RIGHT_MOVE;
			}
		}
		
		
		System.out.println(code);
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
